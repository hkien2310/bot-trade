# --- Scalp EMA + RSI + VWAP Strategy v2 ---
# CHANGELOG v2:
# - Thêm EMA crossover confirmation (chỉ mua khi EMA vừa cross lên)
# - Thêm ADX filter (chỉ trade khi có trend rõ ràng, ADX > 20)
# - Giảm noise bằng cách yêu cầu RSI momentum direction
# - Tăng startup_candle_count để indicators ổn định
# - Tối ưu exit: thêm nhiều điều kiện exit hơn

import numpy as np
from datetime import datetime
from freqtrade.strategy import IStrategy, DecimalParameter, IntParameter
from freqtrade.persistence import Trade
import freqtrade.vendor.qtpylib.indicators as qtpylib
import talib.abstract as ta
import pandas as pd


class ScalpEmaRsiVwap(IStrategy):
    """
    Scalping Strategy v2: EMA + RSI + VWAP + ADX Confluence
    
    Cải tiến từ v1:
    - Thêm ADX để lọc trend mạnh (chỉ trade khi có trend rõ ràng)
    - EMA cross confirmation (chỉ mua gần vùng EMA crossover)
    - RSI direction check (RSI phải đang tăng khi long)
    - Strict exit rules
    """

    # === TIMEFRAME ===
    timeframe = '5m'
    
    # Cần ít nhất 50 candles để indicators ổn định
    startup_candle_count = 50
    
    # === RISK MANAGEMENT ===
    minimal_roi = {
        "0": 0.015,      # 1.5% 
        "20": 0.01,       # 1% sau 20 phút
        "45": 0.005,      # 0.5% sau 45 phút
        "90": 0.002       # 0.2% sau 90 phút — thoát nhanh
    }
    
    stoploss = -0.01      # Stop-loss 1%
    
    # Trailing stop — bảo vệ lợi nhuận khi giá đi đúng hướng
    trailing_stop = True
    trailing_stop_positive = 0.004    # Trail 0.4%
    trailing_stop_positive_offset = 0.008  # Kích hoạt ở 0.8% lãi
    trailing_only_offset_is_reached = True
    
    # Spot only
    can_short = False
    
    # === HYPERPARAMETERS ===
    ema_fast_period = IntParameter(7, 12, default=9, space='buy')
    ema_slow_period = IntParameter(18, 26, default=21, space='buy')
    rsi_buy_lower = IntParameter(35, 50, default=42, space='buy')
    rsi_buy_upper = IntParameter(55, 68, default=62, space='buy')
    adx_threshold = IntParameter(18, 30, default=22, space='buy')
    rsi_sell_upper = IntParameter(65, 80, default=72, space='sell')
    
    # === INDICATORS ===
    def populate_indicators(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        
        # EMA nhanh & chậm
        dataframe['ema_fast'] = ta.EMA(dataframe, timeperiod=self.ema_fast_period.value)
        dataframe['ema_slow'] = ta.EMA(dataframe, timeperiod=self.ema_slow_period.value)
        
        # EMA cross signal (1 khi vừa cross lên, dùng để phát hiện điểm vào tốt)
        dataframe['ema_cross_up'] = qtpylib.crossed_above(
            dataframe['ema_fast'], dataframe['ema_slow']
        )
        # Đếm số candles kể từ cross gần nhất
        dataframe['candles_since_cross'] = 0
        cross_idx = dataframe.index[dataframe['ema_cross_up']]
        for idx in cross_idx:
            pos = dataframe.index.get_loc(idx)
            for j in range(pos, min(pos + 30, len(dataframe))):
                dataframe.iloc[j, dataframe.columns.get_loc('candles_since_cross')] = j - pos
        
        # RSI
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)
        # RSI direction: đang tăng hay giảm (so với 3 candles trước)
        dataframe['rsi_rising'] = dataframe['rsi'] > dataframe['rsi'].shift(3)
        
        # ADX - Average Directional Index
        # ADX > 20 = có trend, ADX < 20 = sideway/choppy → KHÔNG TRADE
        dataframe['adx'] = ta.ADX(dataframe, timeperiod=14)
        
        # VWAP (rolling 48 candles = 4 giờ)
        dataframe['vwap'] = self.calculate_vwap(dataframe)
        
        # Volume filter
        dataframe['volume_mean'] = dataframe['volume'].rolling(window=20).mean()
        
        # Bollinger Bands
        bollinger = qtpylib.bollinger_bands(qtpylib.typical_price(dataframe), window=20, stds=2)
        dataframe['bb_upper'] = bollinger['upper']
        dataframe['bb_lower'] = bollinger['lower']
        dataframe['bb_mid'] = bollinger['mid']
        
        # ATR - Average True Range (đo volatility, dùng cho stop-loss dynamic)
        dataframe['atr'] = ta.ATR(dataframe, timeperiod=14)
        
        return dataframe

    def calculate_vwap(self, dataframe: pd.DataFrame) -> pd.Series:
        typical_price = (dataframe['high'] + dataframe['low'] + dataframe['close']) / 3
        period = 48
        cum_vol = dataframe['volume'].rolling(window=period).sum()
        cum_vol_price = (typical_price * dataframe['volume']).rolling(window=period).sum()
        vwap = cum_vol_price / cum_vol
        return vwap

    # === ENTRY (MUA) ===
    def populate_entry_trend(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        """
        Điều kiện mua CHẶT hơn v1:
        1. EMA9 > EMA21 (uptrend)
        2. Gần vùng EMA cross (trong 15 candles = 75 phút)
        3. Giá > VWAP
        4. RSI 42-62 VÀ đang tăng
        5. ADX > 22 (có trend rõ ràng, không sideway)
        6. Volume đủ lớn
        7. Giá KHÔNG ở trên BB upper (tránh mua đỉnh)
        """
        conditions = []
        
        # 1. Uptrend
        conditions.append(dataframe['ema_fast'] > dataframe['ema_slow'])
        
        # 2. Gần EMA cross (tối đa 15 candles kể từ cross)
        conditions.append(
            (dataframe['candles_since_cross'] > 0) & 
            (dataframe['candles_since_cross'] <= 15)
        )
        
        # 3. Giá trên VWAP
        conditions.append(dataframe['close'] > dataframe['vwap'])
        
        # 4. RSI trong vùng tốt + đang tăng
        conditions.append(dataframe['rsi'] > self.rsi_buy_lower.value)
        conditions.append(dataframe['rsi'] < self.rsi_buy_upper.value)
        conditions.append(dataframe['rsi_rising'])
        
        # 5. ADX > threshold (có trend)
        conditions.append(dataframe['adx'] > self.adx_threshold.value)
        
        # 6. Volume đủ
        conditions.append(dataframe['volume'] > dataframe['volume_mean'] * 0.8)
        
        # 7. Không ở trên BB upper (tránh mua khi đã quá cao)
        conditions.append(dataframe['close'] < dataframe['bb_upper'])
        
        # 8. Volume > 0
        conditions.append(dataframe['volume'] > 0)
        
        if conditions:
            dataframe.loc[
                self._reduce_conditions(conditions),
                'enter_long'] = 1

        return dataframe

    # === EXIT (BÁN) ===
    def populate_exit_trend(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        """
        Exit conditions (bán khi 1 trong các điều kiện đúng):
        
        Signal 1: RSI quá mua (> 72)
        Signal 2: EMA fast cắt xuống dưới EMA slow (trend đảo)
        Signal 3: Giá xuống dưới VWAP VÀ EMA slow (mất momentum hoàn toàn)
        """
        
        # Exit signal 1: RSI overbought
        rsi_exit = dataframe['rsi'] > self.rsi_sell_upper.value
        
        # Exit signal 2: Bearish EMA crossover 
        ema_exit = qtpylib.crossed_below(dataframe['ema_fast'], dataframe['ema_slow'])
        
        # Exit signal 3: Giá rớt dưới cả VWAP lẫn EMA slow
        momentum_loss = (
            (dataframe['close'] < dataframe['vwap']) & 
            (dataframe['close'] < dataframe['ema_slow'])
        )
        
        # Kết hợp: bán khi BẤT KỲ signal nào trigger
        dataframe.loc[rsi_exit | ema_exit | momentum_loss, 'exit_long'] = 1

        return dataframe

    @staticmethod
    def _reduce_conditions(conditions: list) -> pd.Series:
        result = conditions[0]
        for c in conditions[1:]:
            result = result & c
        return result

    def leverage(self, pair: str, current_time: datetime, current_rate: float,
                 proposed_leverage: float, max_leverage: float, entry_tag: str | None,
                 side: str, **kwargs) -> float:
        return 1.0
