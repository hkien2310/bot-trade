# --- Scalp EMA + RSI + VWAP Strategy v4h ---
# CHANGELOG:
# v1: Basic EMA+RSI+VWAP → -98.7% (overtrading + unlimited stake)
# v2: Added ADX, EMA cross proximity, BB guard → -27.9% (better but still losing)
# v3: Hyperopt params (ADX 30, RSI 50-55) → -0.13% (near break-even, low DD)
# v4a: 15m timeframe → worse (-0.36%)  [LOẠI]
# v4f: Relaxed ADX/RSI → worse (-10.85%) [LOẠI]
# v4h: THIS VERSION — Major logic changes:
#   - Higher timeframe confirmation (1h EMA trend)
#   - Stoploss -1.5% (give more room)
#   - ROI adjusted for larger moves
#   - Remove EMA cross proximity (too restrictive, caused 52 trades/498 days)
#   - Add MACD histogram filter
#   - Candle pattern filter (bullish engulfing)

import numpy as np
from datetime import datetime
from freqtrade.strategy import IStrategy, DecimalParameter, IntParameter, informative
from freqtrade.persistence import Trade
import freqtrade.vendor.qtpylib.indicators as qtpylib
import talib.abstract as ta
import pandas as pd


class ScalpEmaRsiVwap(IStrategy):
    """
    Scalping Strategy v4h: Multi-Timeframe + MACD + Candle Patterns
    
    Key insight: v3 chỉ có 52 trades vì EMA cross proximity quá restrictive.
    v4h bỏ EMA cross proximity, thay bằng:
    1. Higher TF confirmation (1h EMA trend phải uptrend)
    2. MACD histogram phải dương (momentum tăng)
    3. Candle body phải đủ lớn (tránh doji/indecision)
    """

    timeframe = '5m'
    startup_candle_count = 50
    
    # Wider ROI — cho trade chạy lâu hơn để capture larger moves
    minimal_roi = {
        "0": 0.02,       # 2% 
        "30": 0.015,      # 1.5% sau 30 phút
        "60": 0.01,       # 1% sau 60 phút
        "120": 0.005,     # 0.5% sau 120 phút
        "240": 0.002      # 0.2% sau 4 giờ
    }
    
    # Stoploss rộng hơn — give more room
    stoploss = -0.015     # 1.5% thay vì 1%
    
    # Trailing stop
    trailing_stop = True
    trailing_stop_positive = 0.005
    trailing_stop_positive_offset = 0.01
    trailing_only_offset_is_reached = True
    
    can_short = False
    
    # Hyperparameters
    ema_fast_period = IntParameter(5, 12, default=8, space='buy')
    ema_slow_period = IntParameter(18, 30, default=21, space='buy')
    rsi_buy_lower = IntParameter(35, 55, default=40, space='buy')
    rsi_buy_upper = IntParameter(55, 70, default=65, space='buy')
    adx_threshold = IntParameter(20, 35, default=25, space='buy')
    rsi_sell_upper = IntParameter(65, 85, default=75, space='sell')
    
    # === HIGHER TIMEFRAME (1h) ===
    @informative('1h')
    def populate_indicators_1h(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        """1h timeframe indicators for trend confirmation."""
        dataframe['ema_fast'] = ta.EMA(dataframe, timeperiod=9)
        dataframe['ema_slow'] = ta.EMA(dataframe, timeperiod=21)
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)
        return dataframe
    
    # === 5m INDICATORS ===
    def populate_indicators(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        
        # EMA
        dataframe['ema_fast'] = ta.EMA(dataframe, timeperiod=self.ema_fast_period.value)
        dataframe['ema_slow'] = ta.EMA(dataframe, timeperiod=self.ema_slow_period.value)
        
        # RSI
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)
        
        # ADX
        dataframe['adx'] = ta.ADX(dataframe, timeperiod=14)
        
        # VWAP (rolling 48 candles = 4 giờ)
        dataframe['vwap'] = self.calculate_vwap(dataframe)
        
        # MACD
        macd = ta.MACD(dataframe, fastperiod=12, slowperiod=26, signalperiod=9)
        dataframe['macd'] = macd['macd']
        dataframe['macdsignal'] = macd['macdsignal']
        dataframe['macdhist'] = macd['macdhist']
        
        # Volume
        dataframe['volume_mean'] = dataframe['volume'].rolling(window=20).mean()
        
        # Bollinger Bands
        bollinger = qtpylib.bollinger_bands(qtpylib.typical_price(dataframe), window=20, stds=2)
        dataframe['bb_upper'] = bollinger['upper']
        dataframe['bb_lower'] = bollinger['lower']
        dataframe['bb_mid'] = bollinger['mid']
        
        # Candle body size (filter out doji/indecision candles)
        dataframe['body_pct'] = abs(dataframe['close'] - dataframe['open']) / dataframe['close'] * 100
        
        return dataframe

    def calculate_vwap(self, dataframe: pd.DataFrame) -> pd.Series:
        typical_price = (dataframe['high'] + dataframe['low'] + dataframe['close']) / 3
        period = 48
        cum_vol = dataframe['volume'].rolling(window=period).sum()
        cum_vol_price = (typical_price * dataframe['volume']).rolling(window=period).sum()
        vwap = cum_vol_price / cum_vol
        return vwap

    # === ENTRY ===
    def populate_entry_trend(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        """
        v4h Entry conditions:
        1. 1h EMA fast > slow (higher TF uptrend) — NEW
        2. 5m EMA fast > slow (local uptrend)
        3. Price > VWAP
        4. RSI 40-65 (neutral zone with room to grow)
        5. ADX > 25 (trend present)
        6. MACD histogram > 0 (bullish momentum) — NEW
        7. Candle body > 0.05% (not a doji) — NEW
        8. Volume sufficient
        9. Price not at BB upper
        """
        conditions = []
        
        # 1. Higher TF trend (1h EMA9 > EMA21)
        conditions.append(dataframe['ema_fast_1h'] > dataframe['ema_slow_1h'])
        
        # 2. Local uptrend
        conditions.append(dataframe['ema_fast'] > dataframe['ema_slow'])
        
        # 3. Price > VWAP
        conditions.append(dataframe['close'] > dataframe['vwap'])
        
        # 4. RSI in range
        conditions.append(dataframe['rsi'] > self.rsi_buy_lower.value)
        conditions.append(dataframe['rsi'] < self.rsi_buy_upper.value)
        
        # 5. ADX strong
        conditions.append(dataframe['adx'] > self.adx_threshold.value)
        
        # 6. MACD histogram positive (bullish momentum)
        conditions.append(dataframe['macdhist'] > 0)
        
        # 7. Candle body significant (not a doji)
        conditions.append(dataframe['body_pct'] > 0.05)
        
        # 8. Volume
        conditions.append(dataframe['volume'] > dataframe['volume_mean'] * 0.7)
        conditions.append(dataframe['volume'] > 0)
        
        # 9. Not at BB upper
        conditions.append(dataframe['close'] < dataframe['bb_upper'])
        
        if conditions:
            dataframe.loc[
                self._reduce_conditions(conditions),
                'enter_long'] = 1

        return dataframe

    # === EXIT ===
    def populate_exit_trend(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        """
        Exit when:
        1. RSI overbought
        2. MACD histogram turns negative (momentum shift)
        3. Price drops below both VWAP and EMA slow
        4. 1h trend reverses
        """
        
        # Exit 1: RSI overbought
        rsi_exit = dataframe['rsi'] > self.rsi_sell_upper.value
        
        # Exit 2: MACD hist turns negative + price below VWAP
        macd_exit = (
            (dataframe['macdhist'] < 0) & 
            (dataframe['close'] < dataframe['vwap'])
        )
        
        # Exit 3: Full momentum loss
        momentum_loss = (
            (dataframe['close'] < dataframe['vwap']) & 
            (dataframe['close'] < dataframe['ema_slow']) &
            (dataframe['ema_fast'] < dataframe['ema_slow'])
        )
        
        # Exit 4: 1h trend reversed
        higher_tf_reversal = dataframe['ema_fast_1h'] < dataframe['ema_slow_1h']
        
        dataframe.loc[
            rsi_exit | macd_exit | momentum_loss | higher_tf_reversal, 
            'exit_long'
        ] = 1

        return dataframe

    @staticmethod
    def _reduce_conditions(conditions: list) -> pd.Series:
        result = conditions[0]
        for c in conditions[1:]:
            result = result & c
        return result

    def leverage(self, pair: str, current_time: datetime, current_rate: float,
                 proposed_leverage: float, max_leverage: float, entry_tag: str | None,
                 side: str, **kwargs) -> float:
        return 1.0
