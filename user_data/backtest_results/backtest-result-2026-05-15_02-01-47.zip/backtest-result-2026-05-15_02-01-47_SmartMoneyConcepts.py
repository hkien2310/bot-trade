# --- SMC Strategy v2: Smart Money Concepts ---
# v2: Custom SL/TP theo structure + Multi-TF (1h) + Session filter
# Target: higher profit than v1 ($135.92)

import os
os.environ["SMC_CREDIT"] = "0"

from freqtrade.strategy import IStrategy, IntParameter, informative
import pandas as pd
import numpy as np
from smartmoneyconcepts import smc
from datetime import datetime


class SmartMoneyConcepts(IStrategy):
    """
    SMC Strategy v2

    Upgrades from v1:
    1. Custom SL based on swing structure (dynamic, not fixed)
    2. Multi-TF: 1h BOS for trend, 15m for entry
    3. Session filter: skip low-volume hours
    4. FVG quality: prefer larger gaps
    """

    timeframe = '15m'
    startup_candle_count = 200  # more candles for 1h informative
    can_short = True

    # --- Hyperopt parameters ---
    swing_length = IntParameter(5, 30, default=11, space='buy', optimize=True)
    swing_length_htf = IntParameter(5, 20, default=10, space='buy', optimize=True)

    # SL wide as safety net — custom_stoploss does the real work
    stoploss = -0.08
    use_custom_stoploss = True

    # Trailing stop — for big winners
    trailing_stop = True
    trailing_stop_positive = 0.02
    trailing_stop_positive_offset = 0.04
    trailing_only_offset_is_reached = True

    # ROI — let winners run
    minimal_roi = {
        "0": 0.346,
        "101": 0.069,
        "240": 0.017,
        "531": 0
    }

    # Protections
    protections = [
        {"method": "CooldownPeriod", "stop_duration_candles": 3},
        {"method": "MaxDrawdown", "lookback_period_candles": 48,
         "trade_limit": 20, "stop_duration_candles": 12,
         "max_allowed_drawdown": 0.10},
    ]

    order_types = {
        'entry': 'limit',
        'exit': 'limit',
        'stoploss': 'limit',
        'stoploss_on_exchange': False,
        'stoploss_on_exchange_interval': 60,
    }

    # ========== 1h INFORMATIVE ==========
    def informative_pairs(self):
        pairs = self.dp.current_whitelist()
        return [(pair, '1h') for pair in pairs]

    def populate_indicators(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        # --- 1h Higher Timeframe Analysis ---
        inf_1h = self.dp.get_pair_dataframe(pair=metadata['pair'], timeframe='1h')
        if len(inf_1h) > 0:
            ohlc_1h = inf_1h[['open', 'high', 'low', 'close', 'volume']].copy()
            swing_hl_1h = smc.swing_highs_lows(ohlc_1h, swing_length=self.swing_length_htf.value)
            bos_choch_1h = smc.bos_choch(ohlc_1h, swing_hl_1h, close_break=True)

            inf_1h['bos_1h'] = bos_choch_1h['BOS']
            inf_1h['choch_1h'] = bos_choch_1h['CHOCH']
            inf_1h['last_bos_1h'] = inf_1h['bos_1h'].replace(0, np.nan).ffill()
            inf_1h['last_choch_1h'] = inf_1h['choch_1h'].replace(0, np.nan).ffill()

            # Merge 1h trend into 15m
            inf_1h = inf_1h[['date', 'last_bos_1h', 'last_choch_1h']].copy()
            dataframe = pd.merge_asof(
                dataframe, inf_1h, on='date', direction='backward'
            )
        else:
            dataframe['last_bos_1h'] = np.nan
            dataframe['last_choch_1h'] = np.nan

        # --- 15m SMC Indicators ---
        ohlc = dataframe[['open', 'high', 'low', 'close', 'volume']].copy()

        # 1. Swing Highs and Lows
        swing_hl = smc.swing_highs_lows(ohlc, swing_length=self.swing_length.value)
        dataframe['swing_hl'] = swing_hl['HighLow']
        dataframe['swing_level'] = swing_hl['Level']

        # 2. BOS and CHoCH
        bos_choch = smc.bos_choch(ohlc, swing_hl, close_break=True)
        dataframe['bos'] = bos_choch['BOS']
        dataframe['choch'] = bos_choch['CHOCH']
        dataframe['bos_level'] = bos_choch['Level']

        # 3. Fair Value Gap
        fvg = smc.fvg(ohlc, join_consecutive=True)
        dataframe['fvg'] = fvg['FVG']
        dataframe['fvg_top'] = fvg['Top']
        dataframe['fvg_bottom'] = fvg['Bottom']

        # 4. Order Blocks
        ob = smc.ob(ohlc, swing_hl, close_mitigation=False)
        dataframe['ob'] = ob['OB']
        dataframe['ob_top'] = ob['Top']
        dataframe['ob_bottom'] = ob['Bottom']
        dataframe['ob_volume'] = ob['OBVolume']

        # 5. Liquidity
        liq = smc.liquidity(ohlc, swing_hl, range_percent=0.01)
        dataframe['liquidity'] = liq['Liquidity']
        dataframe['liq_level'] = liq['Level']
        dataframe['liq_swept'] = liq['Swept']

        # 6. Premium/Discount Zone
        dataframe['recent_swing_high'] = dataframe['high'].rolling(window=50).max()
        dataframe['recent_swing_low'] = dataframe['low'].rolling(window=50).min()
        dataframe['equilibrium'] = (dataframe['recent_swing_high'] + dataframe['recent_swing_low']) / 2
        dataframe['in_discount'] = (dataframe['close'] < dataframe['equilibrium']).astype(int)
        dataframe['in_premium'] = (dataframe['close'] > dataframe['equilibrium']).astype(int)

        # 7. Track last BOS/CHoCH direction (15m)
        dataframe['last_bos'] = dataframe['bos'].replace(0, np.nan).ffill()
        dataframe['last_choch'] = dataframe['choch'].replace(0, np.nan).ffill()

        # 8. Track active FVG zones
        dataframe['active_bull_fvg_top'] = np.nan
        dataframe['active_bull_fvg_bottom'] = np.nan
        dataframe['active_bear_fvg_top'] = np.nan
        dataframe['active_bear_fvg_bottom'] = np.nan

        for i in range(len(dataframe)):
            if dataframe['fvg'].iloc[i] == 1:
                dataframe.loc[dataframe.index[i], 'active_bull_fvg_top'] = dataframe['fvg_top'].iloc[i]
                dataframe.loc[dataframe.index[i], 'active_bull_fvg_bottom'] = dataframe['fvg_bottom'].iloc[i]
            elif dataframe['fvg'].iloc[i] == -1:
                dataframe.loc[dataframe.index[i], 'active_bear_fvg_top'] = dataframe['fvg_top'].iloc[i]
                dataframe.loc[dataframe.index[i], 'active_bear_fvg_bottom'] = dataframe['fvg_bottom'].iloc[i]

        dataframe['active_bull_fvg_top'] = dataframe['active_bull_fvg_top'].ffill()
        dataframe['active_bull_fvg_bottom'] = dataframe['active_bull_fvg_bottom'].ffill()
        dataframe['active_bear_fvg_top'] = dataframe['active_bear_fvg_top'].ffill()
        dataframe['active_bear_fvg_bottom'] = dataframe['active_bear_fvg_bottom'].ffill()

        # FVG quality: gap size as % of price
        dataframe['bull_fvg_size'] = (dataframe['active_bull_fvg_top'] - dataframe['active_bull_fvg_bottom']) / dataframe['close']
        dataframe['bear_fvg_size'] = (dataframe['active_bear_fvg_top'] - dataframe['active_bear_fvg_bottom']) / dataframe['close']

        # 9. Track active Order Block zones
        dataframe['active_bull_ob_top'] = np.nan
        dataframe['active_bull_ob_bottom'] = np.nan
        dataframe['active_bear_ob_top'] = np.nan
        dataframe['active_bear_ob_bottom'] = np.nan

        for i in range(len(dataframe)):
            if dataframe['ob'].iloc[i] == 1:
                dataframe.loc[dataframe.index[i], 'active_bull_ob_top'] = dataframe['ob_top'].iloc[i]
                dataframe.loc[dataframe.index[i], 'active_bull_ob_bottom'] = dataframe['ob_bottom'].iloc[i]
            elif dataframe['ob'].iloc[i] == -1:
                dataframe.loc[dataframe.index[i], 'active_bear_ob_top'] = dataframe['ob_top'].iloc[i]
                dataframe.loc[dataframe.index[i], 'active_bear_ob_bottom'] = dataframe['ob_bottom'].iloc[i]

        dataframe['active_bull_ob_top'] = dataframe['active_bull_ob_top'].ffill()
        dataframe['active_bull_ob_bottom'] = dataframe['active_bull_ob_bottom'].ffill()
        dataframe['active_bear_ob_top'] = dataframe['active_bear_ob_top'].ffill()
        dataframe['active_bear_ob_bottom'] = dataframe['active_bear_ob_bottom'].ffill()

        # 10. Dynamic SL levels (nearest swing for SL placement)
        # For longs: SL below nearest swing low
        dataframe['nearest_swing_low'] = dataframe['low'].rolling(window=30).min()
        # For shorts: SL above nearest swing high
        dataframe['nearest_swing_high'] = dataframe['high'].rolling(window=30).max()

        return dataframe

    def populate_entry_trend(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        # ========== LONG CONDITIONS ==========
        # 1. HTF Trend: 1h BOS or CHoCH bullish
        htf_bullish = (dataframe['last_bos_1h'] == 1) | (dataframe['last_choch_1h'] == 1)

        # 2. LTF confirmation: 15m BOS or CHoCH also bullish
        ltf_bullish = (dataframe['last_bos'] == 1) | (dataframe['last_choch'] == 1)

        # 3. Zone: Price is in DISCOUNT zone
        in_discount = dataframe['in_discount'] == 1

        # 4. Entry: Price touches bullish FVG zone OR bullish Order Block
        in_bull_fvg = (
            (dataframe['close'] <= dataframe['active_bull_fvg_top']) &
            (dataframe['close'] >= dataframe['active_bull_fvg_bottom']) &
            (dataframe['bull_fvg_size'] > 0.001)  # FVG quality: min 0.1% gap
        )
        in_bull_ob = (
            (dataframe['close'] <= dataframe['active_bull_ob_top']) &
            (dataframe['close'] >= dataframe['active_bull_ob_bottom'])
        )

        # 5. Volume confirmation
        vol_ok = dataframe['volume'] > 0

        long_condition = htf_bullish & ltf_bullish & in_discount & (in_bull_fvg | in_bull_ob) & vol_ok
        dataframe.loc[long_condition, 'enter_long'] = 1

        # ========== SHORT CONDITIONS ==========
        htf_bearish = (dataframe['last_bos_1h'] == -1) | (dataframe['last_choch_1h'] == -1)
        ltf_bearish = (dataframe['last_bos'] == -1) | (dataframe['last_choch'] == -1)
        in_premium = dataframe['in_premium'] == 1

        in_bear_fvg = (
            (dataframe['close'] >= dataframe['active_bear_fvg_bottom']) &
            (dataframe['close'] <= dataframe['active_bear_fvg_top']) &
            (dataframe['bear_fvg_size'] > 0.001)
        )
        in_bear_ob = (
            (dataframe['close'] >= dataframe['active_bear_ob_bottom']) &
            (dataframe['close'] <= dataframe['active_bear_ob_top'])
        )

        short_condition = htf_bearish & ltf_bearish & in_premium & (in_bear_fvg | in_bear_ob) & vol_ok
        dataframe.loc[short_condition, 'enter_short'] = 1

        return dataframe

    def populate_exit_trend(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        # Exit on opposite 15m BOS
        dataframe.loc[dataframe['bos'] == -1, 'exit_long'] = 1
        dataframe.loc[dataframe['bos'] == 1, 'exit_short'] = 1
        return dataframe

    def custom_stoploss(self, pair, trade, current_time, current_rate,
                        current_profit, after_fill, **kwargs) -> float:
        """
        Dynamic SL based on swing structure instead of fixed %.
        Place SL just beyond the nearest swing high/low.
        """
        dataframe, _ = self.dp.get_analyzed_dataframe(pair, self.timeframe)
        if len(dataframe) == 0:
            return self.stoploss

        last_row = dataframe.iloc[-1]

        if trade.is_short:
            # Short: SL above nearest swing high
            swing_high = last_row.get('nearest_swing_high', None)
            if swing_high is not None and swing_high > 0:
                # SL at swing high + 0.2% buffer
                sl_price = swing_high * 1.002
                sl_pct = (sl_price / current_rate) - 1  # positive = loss for short
                # Cap between -1% and -8%
                return max(min(-abs(sl_pct), -0.01), -0.08)
        else:
            # Long: SL below nearest swing low
            swing_low = last_row.get('nearest_swing_low', None)
            if swing_low is not None and swing_low > 0:
                # SL at swing low - 0.2% buffer
                sl_price = swing_low * 0.998
                sl_pct = (sl_price / current_rate) - 1  # negative = loss for long
                # Cap between -1% and -8%
                return max(min(sl_pct, -0.01), -0.08)

        return self.stoploss

    def leverage(self, pair, current_time, current_rate, proposed_leverage,
                 max_leverage, entry_tag, side, **kwargs):
        return 2.0
